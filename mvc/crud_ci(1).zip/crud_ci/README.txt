Jangan lupa import file database (ci_project.sql), kemudian atur koneksi databasenya di application/config/database.php.
